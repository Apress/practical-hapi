'use strict';

const Hapi = require('@hapi/hapi');
const Auth = require('./auth');

const start = async () => {

    const server = Hapi.server({ port: 8000 });

    await server.register(require('@hapi/basic'));
	await server.register({plugin:Auth});
	

    server.auth.strategy('simple', 'basic', { validate : Auth.validate });

    server.route({
        method: 'GET',
        path: '/',
        options: {
            auth: 'simple'
        },
        handler: function (request, h) {
			console.log(h);
            return request.auth.credentials;
				
			
        }
    });

    await server.start();

    console.log('server running at: ' + server.info.uri);
};

start();