'use strict';

const Hapi = require('@hapi/hapi');

const users = {
    john: {
        username: 'john',
        password: 'pass1',   
        name: 'John Doe',
        id: '2133d32a'
    }
};

const validate = async (request, username, password) => {

    const user = users[username];
    if (!user) {
        return { credentials: null, isValid: false };
    }

    var isValid = false;
	if(password === user.password)
	{
		isValid = true;
	}
    const credentials = { id: user.id, name: user.name, username: user.username };

    return { isValid, credentials };
};

const start = async () => {

    const server = Hapi.server({ port: 4000 });

    await server.register(require('@hapi/basic'));
	



    server.auth.strategy('simple', 'basic', { validate });

    server.route({
        method: 'GET',
        path: '/',
        options: {
            auth: 'simple'
        },
        handler: function (request, h) {
			console.log(h);
            return request.auth.credentials;
				
			
        }
    });

    await server.start();

    console.log('server running at: ' + server.info.uri);
};

start();