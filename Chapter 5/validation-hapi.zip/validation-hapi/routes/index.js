'use strict';
const joi = require('joi');
//configureroutes will be used in the main server.js file to get the corresponding server.js file.
    

exports.configureRoutes = (server) =>{
    return server.route([
        {   
           method:'GET',
           path:'/home/{name}',
           handler: (request, h) => {
           return `Hello ${request.params.name}!`;}
        },
        {   
           method:'POST',
           path:'/home/date/required',
           config: {
                validate: {
                 payload: joi.object({ date:joi.date().required()
                 })
             }
         },
           handler: (request, h) => {
           return request.payload;}
        },
        {   
           method:'POST',
           path:'/home/create/travel',
           config: {
               validate: {
                  payload: joi.object({
                       from :joi.date().min('now').required(),
                       to:joi.date().greater(joi.ref('from')).required()
                       })
                   }
               },
           handler: (request, h) => {
           return request.payload;
           }
        }
       ]);
}