This app discusses 
clubbing routes, 
exporting routes
validating routes - joi
===========================================================
What it does not discuss
Glue: A way to configure, organise your app, if you are using multiple route files, and a manifest.
Joi in Depth
===========================================================
