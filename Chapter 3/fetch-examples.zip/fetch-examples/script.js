// Code goes here

async function loadDoc() {
  let url = 'https://api.github.com/users';
  let response = await fetch(url).then(function(response) {
      // response.json() returns a new promise that resolves with the full response text
      // when it loads
      return response.json();
    })
    .then(function(json) {
      // ...and here's the content of the remote file
      document.getElementById('demo').innerHTML = (JSON.stringify(json)); // {"name": "iliakan", isAdmin: true}
    });
}

function loadDoc2() {
  let url = 'https://api.github.com/users';
  let response = fetch(url).then(function(response) {
      // response.json() returns a new promise that resolves with the full response text
      // when it loads
      return response.json();
    })
    .then(function(json) {
      // ...and here's the content of the remote file
      document.getElementById('demo').innerHTML = (JSON.stringify(json)); // {"name": "iliakan", isAdmin: true}
    });
}