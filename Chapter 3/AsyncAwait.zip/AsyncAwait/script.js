async function loadDoc() {
let url = 'https://api.github.com/users';
try{
const response = await fetch(url);
const json = await response.json();
document.getElementById('demo').innerHTML = 
(JSON.stringify(json));
}catch(err)
{ console.log('fetch failed - async syntax', err);
}}