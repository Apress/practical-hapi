module.exports = 
{
  userController:require('./UserController')
}