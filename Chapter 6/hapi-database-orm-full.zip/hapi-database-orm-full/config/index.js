const sequelize = require('sequelize');
const appConfig = require('./appConfig');
const dbConfig = require('./dbConfig');

module.exports = 
  {
    appConfig:appConfig,
    dbConfig:dbConfig
  }  
