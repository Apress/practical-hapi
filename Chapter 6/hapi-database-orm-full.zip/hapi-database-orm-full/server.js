'use strict';

const hapi = require('@hapi/hapi');
const auth = require('./auth');
const routes = require('./routes');
const config = require('./config');
const sequelize = require('sequelize');


const start = async () => {
    console.log(config.appConfig.DEVELOPMENT.APP_PORT);
    const server = hapi.server({ port: config.appConfig.DEVELOPMENT.APP_PORT, debug: { request: ['error'] } });

    

    await server.register(require('@hapi/basic'));
	await server.register({plugin:auth});
	

    server.auth.strategy('simple', 'basic', { validate : auth.validate });

    server.route(routes);
    await server.start();

    console.log('server running at: ' + server.info.uri); //Print Order - 1

   
    
   
};
start();

