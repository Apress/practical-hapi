//\utils\index.js
module.exports = {
    userUtil:require('./userUtil')
}