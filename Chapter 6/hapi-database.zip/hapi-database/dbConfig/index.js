const Sequelize = require('sequelize');

const seq = new Sequelize('pollme', 'root', 'admin', {
  host: 'localhost',
  port:'3306',
  dialect: 'mysql'
});

seq.authenticate().then(
    ()=>{console.log("Database connection established.");}
).catch(err=>
    {
      console.error('Connection Disrupted.', err);}
    );