'use strict';

const Hapi = require('@hapi/hapi');
const Connection = require('./dbConfig');

const start = async () => {

    const server = Hapi.server({ port: 8000, app: {app_name:'hapi_database'} }); //Modified to demo Nodemon.

    await server.start();

   

    console.log('server running at: ' + server.info.uri);
    console.log('*App Name iS: ' + server.settings.app.app_name); //Added to demo Nodemon.
   
};

start();