Node Modules are constantly updated and 
during the writing of the book, the package dependency was called: hapi.
Now, its available under @hapi/hapi
Please remain updated with the npm repository and change what needs to be changed.